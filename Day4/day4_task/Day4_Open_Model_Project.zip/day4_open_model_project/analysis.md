# Day 4 Analysis — Will It Fit, and May I Use It?

**Date checked:** 30 September 2026

## Scenario statement

My scenario is a small local AI assistant for a college student. The assistant will be used for coding explanations, short summaries and simple study questions. I will run one open model locally on an **8 GB RAM laptop using the CPU**, with a practical model-memory budget of **6 GB** so that the operating system and other applications still have room to run. The intended user is one student, not a public service.

The licensing situation is important because the model may later be used in a college project or a small commercial prototype. Therefore, I will not treat every model described as “open” as automatically open-source. I will check the exact licence and its conditions before redistribution or commercial deployment.

The main model used for the numerical experiment is **Qwen3-4B**. The official Qwen configuration reports 4.02B parameters, 36 hidden layers, 8 key/value heads and a head dimension of 128. The model card identifies the licence as Apache 2.0. The Ollama Qwen3 4B page currently provides a Q4_K_M build of about 2.5 GB and lists tools support. [Qwen model card](https://huggingface.co/Qwen/Qwen3-4B) and [Ollama Qwen3:4b](https://ollama.com/library/qwen3:4b).

## 3.1 Explanation of the five concepts

### 1. Model weights

Model weights are the stored numerical parameters of a neural network. Their memory is mainly determined by the number of parameters multiplied by the number of bytes used for each parameter.

For this experiment, Qwen3-4B has about 4.02 billion parameters. Using the estimator's simplified Q4 assumption of 0.5 bytes per parameter gives:

`4.02 billion × 0.5 bytes ≈ 2.01 GB`

The weight memory does not increase just because I ask for a longer context. It is tied to the model and the precision/quantization used.

Weights control the **fit** side of the decision. If the weight file alone is too large for the available memory, the model cannot be comfortably served under the chosen budget. Ignoring the parameter count or precision can make a model appear smaller than it really is. The limitation in this scenario is that even a small 4B model has a substantial base memory cost before KV cache and runtime overhead are added.

### 2. Quantization

Quantization stores model weights using fewer bits/bytes. In the estimator I use the simplified bytes-per-parameter values Q8=1.0, Q6=0.75, Q5=0.625, Q4=0.5, Q3=0.375 and Q2=0.25.

For Qwen3-4B, the estimated Q4 weight memory is about 2.01 GB, while Q8 is about 4.02 GB. Therefore, Q4 saves about 2 GB compared with Q8 in this simplified calculation.

Quantization controls **fit** and can also affect output quality. Lower precision normally reduces memory, but it can introduce more approximation error. The estimator does not measure quality loss; that must be evaluated separately.

The limitation in my scenario is that choosing an extremely small quantization only because it fits could reduce the quality of coding or reasoning responses. I therefore want the lowest-memory setting that still gives acceptable task quality, rather than simply the smallest possible file.

### 3. KV cache and context length

During generation, the model keeps key/value attention information for tokens already in the context. This is the KV cache. Unlike the fixed weights, the KV cache grows with the number of context tokens.

For a decoder model, the simplified KV calculation used here is:

`KV bytes = 2 × layers × KV heads × head dimension × context tokens × bytes per KV value`

For Qwen3-4B, using 36 layers, 8 KV heads, head dimension 128 and FP16 KV values:

`2 × 36 × 8 × 128 × context × 2`

At 4,096 tokens this is about 0.60 GB. At 8,192 tokens it is about 1.21 GB. At 16,384 tokens it is about 2.42 GB.

This matters especially for an agent that keeps adding tool results to a conversation. A model can fit at a short context and become much more memory-intensive at a long context even though its weights have not changed.

In this particular 6 GB estimate, Qwen3-4B Q4 remains below the budget through 16K context. However, the real maximum should not be treated as exactly 16K because the formula is only an estimate and the operating system/runtime also needs memory. A safer operating point is 8K context.

### 4. Model card

A model card is the main technical and usage documentation for a model. It can provide the model family, parameter size, architecture, context length, supported capabilities and licence information.

I used the official Qwen3-4B model card for the architecture and licence, Google's official Gemma 3 model card for Gemma 3, and Meta's Llama 3.2 model card for Llama 3.2. The official sources were checked on 30 September 2026.

Ignoring the model card can cause two different mistakes: I may estimate the wrong architecture/memory requirements, or I may assume that a model can be used commercially or redistributed when its licence says otherwise.

For my scenario, the limitation is that model cards describe the model, not the exact memory consumed by every local runtime build. That is why the estimate must still be checked against actual Ollama output.

### 5. Open-weight vs open-source licensing

Open-weight means that model weights are available to users. It does **not** automatically mean that the model is licensed under a standard open-source licence.

This distinction controls **permission**, not memory. The exact licence decides what I may do with the model, including commercial use, redistribution and other conditions.

Qwen3-4B is listed under **Apache License 2.0**. Gemma 3 uses the **Gemma Terms of Use**, rather than Apache 2.0. Llama 3.2 uses the **Llama 3.2 Community License**, described by Meta as a custom commercial licence. The Llama licence also includes redistribution conditions such as providing the agreement and displaying “Built with Llama” when applicable.

Therefore, size alone cannot decide my final model choice. A model that fits can still be unsuitable for a particular product if its licence conditions do not match that product.

## 3.2(a) Memory estimate table

**Available memory budget: 6 GB**

The following figures are produced by `src/estimator.py`. The estimator uses Q4=0.5 bytes/parameter and FP16 KV values. A 10% runtime-overhead allowance is added to weights plus KV cache.

| Model | Params (B) | Precision | Context (K) | Weights (GB) | KV cache (GB) | Total (GB) | Fits in 6 GB? |
|---|---:|---|---:|---:|---:|---:|---|
| Qwen3-4B | 4.02 | Q4 | 4 | 2.01 | 0.60 | 2.87 | Yes |
| Qwen3-4B | 4.02 | Q4 | 8 | 2.01 | 1.21 | 3.54 | Yes |
| Qwen3-4B | 4.02 | Q4 | 16 | 2.01 | 2.42 | 4.88 | Yes |
| Qwen3-4B | 4.02 | Q8 | 8 | 4.02 | 1.21 | 5.75 | Yes |

The output is also saved in `screenshots/estimator_output.txt`.

## 3.2(b) Open-model comparison

| Basis | Qwen3-4B | Gemma 3 4B | Llama 3.2 3B |
|---|---|---|---|
| Full model name/version | Qwen3-4B | Gemma 3 4B | Llama 3.2 3B |
| Publisher | Qwen | Google DeepMind | Meta |
| Total / active parameters | 4.02B | 4B class | 3.21B |
| MoE? | No; dense model | No for 4B model | No |
| Context window | Qwen3-4B model card: 32K; current Qwen3-4B config shows 40,960 max positions | 128K | 128K |
| Licence | Apache License 2.0 | Gemma Terms of Use | Llama 3.2 Community License |
| Commercial use allowed? | Apache 2.0 permits commercial use subject to its conditions | The terms permit use subject to the Gemma agreement and prohibited-use conditions | Commercial use is permitted subject to the custom licence and its conditions |
| Extra conditions | Preserve licence/copyright notices and comply with Apache terms | Follow Gemma Terms of Use and prohibited-use policy | Follow licence/AUP; redistribution has additional notice/attribution conditions |
| Tool calling stated? | Yes; Qwen3/Ollama page lists tools and Qwen model documentation describes agent capabilities | The official Gemma 3 model card is focused on multimodal/text generation capabilities; tool calling is not treated as a primary model-card guarantee here | Ollama lists tools; Meta documentation describes agentic retrieval and tool-use-related capabilities |
| GGUF/Ollama build | Yes | Yes | Yes |
| Ollama Q4 download size checked | About 2.5 GB for `qwen3:4b` Q4_K_M | About 3.3 GB for `gemma3:4b` Q4_K_M | About 2.0 GB for `llama3.2:3b` |
| Estimated total used in scenario | 3.54 GB at Q4/8K | Approx. similar order, but architecture-specific KV parameters must be used for a precise estimate | Smaller weight base; actual total depends on runtime/context |
| Fits 6 GB budget? | Yes by the estimator | The Ollama Q4 download is below the budget, but runtime/KV must still be checked | Yes by the size/context assumptions |
| Date checked | 2026-09-30 | 2026-09-30 | 2026-09-30 |

**Sources checked:** Qwen's official model card and configuration, Google's official Gemma 3 model card and Terms of Use, Meta's official Llama 3.2 model card/licence, and the three Ollama library pages.

Qwen3-4B is shown by Ollama as 4.02B parameters, Q4_K_M, about 2.5 GB and with tools support. citeturn0search0turn0search4

Gemma 3's official model card says the 4B model has a 128K context window and open weights; Google's current Terms of Use are the governing terms. Ollama lists the 4B Q4_K_M build at about 3.3 GB. citeturn1search0turn1search15turn0search1

Meta's Llama 3.2 model card states 3.21B parameters for the 3B model, 128K context and the Llama 3.2 Community License. Ollama lists the 3B build at about 2.0 GB and describes tool use. citeturn1search4turn0search2

## 3.3 Context length and quantization observation

I selected Qwen3-4B because its official configuration exposes the architecture values needed by the estimator.

### Context length — Q4 fixed

| Context | Weights GB | KV cache GB | Total GB | Fits? |
|---:|---:|---:|---:|---|
| 2K | 2.01 | 0.30 | 2.54 | Yes |
| 4K | 2.01 | 0.60 | 2.87 | Yes |
| 8K | 2.01 | 1.21 | 3.54 | Yes |
| 16K | 2.01 | 2.42 | 4.88 | Yes |

Only the KV-cache component grows with context in this simplified formula. The weights stay at about 2.01 GB because the model and quantization have not changed.

### Quantization — 8K context fixed

| Quantization | Weights GB | KV cache GB | Total GB | Fits? |
|---|---:|---:|---:|---|
| Q2 | 1.00 | 1.21 | 2.43 | Yes |
| Q3 | 1.51 | 1.21 | 2.99 | Yes |
| Q4 | 2.01 | 1.21 | 3.54 | Yes |
| Q5 | 2.51 | 1.21 | 4.09 | Yes |
| Q6 | 3.01 | 1.21 | 4.64 | Yes |
| Q8 | 4.02 | 1.21 | 5.75 | Yes |

Only the weight component changes when quantization changes in this simplified experiment. The KV cache remains the same because context and KV precision remain fixed.

For this 6 GB scenario, **8K Q4** is the practical operating point I would use. It leaves a larger memory margin than Q8 while avoiding the more aggressive compression of Q2/Q3. The trade-off is that Q4 may give up some numerical fidelity compared with higher precision, while longer context increases KV memory.

The calculation is an estimate, not a promise that a real process will stop at the exact calculated number. Ollama's actual build size already demonstrates why the simple parameter × bytes calculation should not be treated as the exact file/process size.

## 3.4 Estimate versus reality

The Day 4 task requires one model actually installed on a machine and asks for `ollama list`, `ollama ps`, processor information, the estimate and an explanation of any difference.

The project includes `src/collect_ollama.py`, which records the actual commands into `screenshots/ollama_machine_output.txt`. The supplied environment for preparing this project does not expose the user's Windows Ollama installation, so I have **not invented an `ollama list` or `ollama ps` result**.

To complete this one machine-specific evidence item on the actual laptop, run:

```powershell
python src/collect_ollama.py
ollama list
ollama ps
```

Then take the required screenshots and place them in `screenshots/`. The processor column should identify whether the model is using CPU, GPU or a split between them. That information matters because the same model can run with different speed and memory behaviour depending on where the layers and KV cache are allocated.

For Qwen3-4B Q4 at 8K, my estimate is **2.01 GB weights + 1.21 GB KV cache = 3.22 GB before the 10% overhead allowance, or 3.54 GB including that allowance**. A real Ollama process can differ because of the actual quantized build, runtime allocations, context defaults, backend and architecture-specific implementation.

## 3.5 Suitability analysis

For the stated scenario, my selected configuration is **Qwen3-4B, Q4_K_M, 8K context**, with an Apache License 2.0 model licence. The numerical estimate is about 3.54 GB under my 6 GB practical budget. Ollama currently lists a Q4_K_M build of about 2.5 GB and explicitly exposes tools support. The Qwen model card also identifies Apache 2.0. These facts make it suitable for the intended single-user coding/summarisation experiment, while leaving meaningful memory headroom for the operating system and runtime.

The runner-up is **Llama 3.2 3B**. Its smaller parameter count and approximately 2.0 GB Ollama build make it attractive for a constrained laptop, and Meta describes the 3B model as supporting use cases including agentic retrieval and summarisation. I did not select it as the main model because this scenario places value on Qwen3's coding/reasoning and tool-oriented capabilities as documented by Qwen/Ollama. This is a scenario-specific trade-off rather than a universal ranking of the models.

The recommendation would change if the machine had substantially more memory, if the project had to redistribute the model under a different legal/commercial requirement, if a much longer context were essential, or if a particular tool-calling interface became mandatory. In particular, a commercial/public release requires a fresh licence check rather than assuming that “open-weight” means “open-source”.

## 3.6 Conclusion

Model size should carry the most weight when the hardware memory is the limiting resource. For example, on a laptop with a small memory budget, a larger model may be impossible to load even before considering its quality.

Quantization should carry the most weight when a model is close to the hardware limit and there are several precision choices. Lower precision reduces weight memory, but the user should accept the associated quality trade-off rather than choosing the smallest number automatically.

Context length should carry the most weight for applications that maintain long conversations, process long documents, or run agents that accumulate tool results. The weights do not grow with context, but the KV cache does, so a model that fits at 4K can require much more memory at 16K or beyond.

Licence should carry the most weight when the model will be redistributed, embedded in a commercial product, exposed as a public service, or shared with other users. In that situation, a model that fits perfectly can still be unsuitable if its exact licence conditions do not permit the intended use.

The main lesson from this task is therefore that **fit and permission are separate decisions**. The memory estimate answers “can my machine plausibly run this configuration?”, while the model card and exact licence answer “am I allowed to use, modify, distribute or commercialise it in this situation?” Both checks should happen before downloading and deploying a local model.

## Sources

- Qwen3-4B model card: https://huggingface.co/Qwen/Qwen3-4B
- Qwen3-4B configuration: https://huggingface.co/Qwen/Qwen3-4B/blob/main/config.json
- Qwen3-4B Ollama page: https://ollama.com/library/qwen3:4b
- Google Gemma 3 model card: https://ai.google.dev/gemma/docs/core/model_card_3
- Google Gemma Terms of Use: https://ai.google.dev/gemma/terms
- Gemma 3 4B Ollama page: https://ollama.com/library/gemma3:4b
- Meta Llama 3.2 model card: https://github.com/meta-llama/llama-models/blob/main/models/llama3_2/MODEL_CARD.md
- Llama 3.2 3B licence: https://huggingface.co/meta-llama/Llama-3.2-3B-Instruct/blob/main/LICENSE.txt
- Llama 3.2 Ollama page: https://ollama.com/library/llama3.2
